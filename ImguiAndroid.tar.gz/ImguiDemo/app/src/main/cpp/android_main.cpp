#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES/gl.h>
#include <cassert>
#include <cmath>

#include <ImGui/imgui.h>
#include <ImGui/imgui_impl_opengl3.h>
#include <ImGui/imgui_impl_android.h>
#include <ImGui/cousine_regular.h>
#include <ImGui/roboto_medium.h>

namespace {
    
    EGLDisplay g_display = EGL_NO_DISPLAY;
    EGLSurface g_surface = EGL_NO_SURFACE;
    EGLConfig  g_config;    
    EGLContext g_context = EGL_NO_CONTEXT;
    EGLint     g_width = 0;
    EGLint     g_height = 0;

    bool g_has_focus = false;
    bool g_has_window = false;
    bool g_is_visible = false;

    bool animating() {
	return g_has_focus && g_has_window && g_is_visible;
    }

    // Initializes ImGui, and registers the input
    // event handler to the application.
    void imgui_init(struct android_app* app) {
	ImGui::CreateContext();
	ImGui_ImplAndroid_Init(app);
	ImGui_ImplOpenGL3_Init("#version 100");

	// Change a bit preferences for better rendering on
	// a phone (tiny highres screen -> use large font)
	ImGuiIO& io = ImGui::GetIO();
	float font_size = 40.0f;
	io.FontDefault = io.Fonts->AddFontFromMemoryCompressedTTF(
	    roboto_medium_compressed_data,
	    roboto_medium_compressed_size, font_size
	);

	ImGuiStyle& style = ImGui::GetStyle();
	style.ScrollbarSize = 40.0f;
	style.GrabMinSize   = 15.0f;	
    }

    // Terminates ImGui, and deallocates all resources
    // allocated by ImGui.
    void imgui_terminate(struct android_app* app) {
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplAndroid_Shutdown();
	ImGui::DestroyContext();
    }

    // Called before rendering operations.
    void imgui_begin_frame(struct android_app* app) {
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame();
	ImGui::NewFrame();
    }

    // Called after all rendering operations, right before
    // swapping buffers.
    void imgui_end_frame(struct android_app* app) {
	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	ImGui_ImplAndroid_EndFrame();
    }
    
    // Initializes all graphics-related stuff.
    void gfx_init_whats_needed(struct android_app* app) {
	
	// Get display and initialize GLES
	if(g_display == EGL_NO_DISPLAY) {
	    g_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	    eglInitialize(g_display, 0, 0);
	}

	// Choose best matching config and create surface
	if(g_surface == EGL_NO_SURFACE) {
	    const EGLint attribs[] = {
		EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR, // request OpenGL ES 3.0
		EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
		EGL_BLUE_SIZE,  8,
		EGL_GREEN_SIZE, 8,
		EGL_RED_SIZE,   8,
		EGL_DEPTH_SIZE, 16,	    
		EGL_NONE
	    };
	    // EGLint format;
	    EGLint numConfigs;
	    
	    // Get the number of matching configs.
	    eglChooseConfig(g_display, attribs, nullptr, 0, &numConfigs);
	    EGLConfig* supportedConfigs = new EGLConfig[numConfigs];
	    assert(supportedConfigs != nullptr);
	    // Do that again now that we know the number of configs.
	    eglChooseConfig(g_display, attribs, supportedConfigs, numConfigs, &numConfigs);
	    assert(numConfigs != 0);
	    // Find the best matching config. among them.
	    int i = 0;
	    for (; i < numConfigs; i++) {
		auto& cfg = supportedConfigs[i];
		EGLint r, g, b, d;
		if (eglGetConfigAttrib(g_display, cfg, EGL_RED_SIZE,   &r) &&
		    eglGetConfigAttrib(g_display, cfg, EGL_GREEN_SIZE, &g) &&
		    eglGetConfigAttrib(g_display, cfg, EGL_BLUE_SIZE,  &b) &&
		    eglGetConfigAttrib(g_display, cfg, EGL_DEPTH_SIZE, &d) &&
		    r == 8 && g == 8 && b == 8 && d == 16 ) {
		    g_config = supportedConfigs[i];
		    break;
		}
	    }
	    // In the worst case, use the first one.
	    if (i == numConfigs) {
		g_config = supportedConfigs[0];
	    }
	    delete[] supportedConfigs;
	    g_surface = eglCreateWindowSurface(g_display, g_config, app->window, nullptr);
	}

	if(g_context == EGL_NO_CONTEXT) {
	    // Important: create an OpenGL es 2.0 context. Without this, it defaults to
	    // an OpenGL es 1.0 context, and glCreateProgram() / glCreateBuffer() silently
	    // fail and return 0 (banged my head to the wall before figuring out !!)
	    const EGLint context_attribs_2[] = {
		EGL_CONTEXT_CLIENT_VERSION, 2,
		EGL_NONE
	    };
	    g_context = eglCreateContext(g_display, g_config, nullptr, context_attribs_2);
	}

	eglMakeCurrent(g_display, g_surface, g_surface, g_context);	
	eglQuerySurface(g_display, g_surface, EGL_WIDTH,  &g_width);
	eglQuerySurface(g_display, g_surface, EGL_HEIGHT, &g_height);

	// Initialize ImGui if not already initialized.
	if(ImGui::GetCurrentContext() == nullptr) {
	    imgui_init(app);
	}
    }

    // Terminates all graphics-related stuff, deallocates all graphic resources.
    void gfx_terminate(struct android_app* app) {

	if(ImGui::GetCurrentContext() != nullptr) {	
	    imgui_terminate(app);
	}
	
	if (g_display != EGL_NO_DISPLAY) {
	    eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	    if (g_context != EGL_NO_CONTEXT) {
		eglDestroyContext(g_display, g_context);
	    }
	    if (g_surface != EGL_NO_SURFACE) {
		eglDestroySurface(g_display, g_surface);
	    }
	    eglTerminate(g_display);
	}
	g_display = EGL_NO_DISPLAY;
	g_context = EGL_NO_CONTEXT;
	g_surface = EGL_NO_SURFACE;
    }


    // The function that draws stuff.
    //   imgui_begin_frame() is called as soon as possible.
    //   imgui_end_frame() is called at the end, right
    //   before swapping buffers.
    void gfx_draw(struct android_app* app) {
	
	gfx_init_whats_needed(app);
	
	if (g_display == EGL_NO_DISPLAY) {
	    return;
	}
	imgui_begin_frame(app);

	static int frame = 0;
	++frame;
	float r = 0.5f * (1.0f + float(sin(0.004*double(frame)+0.5)));	
	float g = 0.5f * (1.0f + float(sin(0.008*double(frame)+0.3)));	
	float b = 0.5f * (1.0f + float(sin(0.004*double(frame))));
	glClearColor(r,g,b,1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	ImGui::ShowDemoWindow();
	
	imgui_end_frame(app);
	eglSwapBuffers(g_display, g_surface);
    }

    // Event handler for application commands.
    void cmd_handler(struct android_app* app, int32_t cmd) {
	switch (cmd) {
		
	    case APP_CMD_INIT_WINDOW:
		g_has_window = (app->window != nullptr);
		break;
		
	    case APP_CMD_TERM_WINDOW:
		// I do not understand exactly what's going on here:
		// This event may be triggered when the app is re-started.
		// Like in the endless-tunnel demo of the NDK, we just destroy
		// the surface. If the application is restarted, the surface
		// will be re-created by  gfx_init_whats_needed(), that is called at the
		// beginning of gfx_draw(). It happens when a physical keyboard
		// is connected/disconnected while the app is running (but I do
		// not know why, see comments at the beginning of this file).
		// At least the app no longer crashes.
		if(g_surface != EGL_NO_SURFACE) {
		    eglDestroySurface(g_display, g_surface);
		    g_surface = EGL_NO_SURFACE;
		}
		g_has_window = false;
		break;
		
	    case APP_CMD_GAINED_FOCUS:
		g_has_focus = true;
		break;
		
	    case APP_CMD_LOST_FOCUS:
		g_has_focus = false;
		break;
		
	    case APP_CMD_START:
		g_is_visible = true;
		break;
		
	    case APP_CMD_STOP:
		g_is_visible = false;
		break;

	    case APP_CMD_SAVE_STATE:
		break;

	    case APP_CMD_PAUSE:
		break;
		
	    case APP_CMD_RESUME:
		break;

	    case APP_CMD_WINDOW_RESIZED:
		break;
		
	    case APP_CMD_CONFIG_CHANGED:
		break;

	    case APP_CMD_LOW_MEMORY:
		break;
	}
    }
}

extern "C" void android_main(struct android_app* app);

void android_main(struct android_app* app) {

    app->userData = nullptr; 
    app->onAppCmd = cmd_handler;
    // Note: app->onInputEvent is initialized by
    // ImGui_ImplAndroid_Init(app).
    
    for(;;) {
        int ident;
	int events;
        struct android_poll_source* source;
        while (
	     (ident = ALooper_pollAll(
	         animating() ? 0 : -1, // 0 = non-blocking, -1 = blocking
		 nullptr,
		 &events, 
                 (void**)&source)
              ) >= 0
	) {
	    // process event
            if (source != nullptr) {
                source->process(app, source);
            }

	    // Check if we are exiting.
	    if (app->destroyRequested != 0) {
		gfx_terminate(app);
		return;
	    }
	}

        if(animating()) {
	    gfx_draw(app);
	}
    }
}

/************************************************************************
  Notes, references, links:

  OpenGL es 3.0 is not always supported by devices (even if they run API level 
  >= 18), see:  https://developer.android.com/guide/topics/graphics/opengl

  ************************************************************************/
