ImGui bindings for Android and demo app.
Bruno Levy, Thu Aug 30 15:42:52 CEST 2018.
Uses NativeActivity (pure C++ app, no Java).
C++ sources are in: app/src/main/cpp.
My changes to ImGui (ver. 1.62) are indicated by [Bruno] tags.

Implemented inputs:
  fingers/stylus/bluetooth mouse/virtual keyboard (push 'back' key to
  activate)/bluetooth keyboard


To compile:
1) install Android NDK
2) ./gradlew assembleRelease
3) plug device
4) adb install app/build/outputs/apk/debug/app-debug.apk

